﻿
select * from De