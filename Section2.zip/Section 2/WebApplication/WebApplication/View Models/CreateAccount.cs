﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebApplication.View_Models
{
    public class CreateAccount
    {
        [StringLength(20), Display(Name = "First Name:")]
        [Required(ErrorMessage = "This field is required.")]
        public string FirstName { get; set; }

        [StringLength(40), Display(Name = "Last Name:")]
        [Required(ErrorMessage = "This field is required.")]
        public string LastName { get; set; }

        [DataType(DataType.EmailAddress), Display(Name = "Email address:")]
        [Required(ErrorMessage = "This field is required.")]
        public string EmailAddress { get; set; }

        [Required, DataType(DataType.Date), Display(Name = "Date of birth:")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DoB { get; set; }

        [Display(Name = "Username:")]
        [Required(ErrorMessage = "This field is required.")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.Password), Display(Name = "Password:")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage = "This field is required."), Display(Name = "Confirm Password:")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }
}