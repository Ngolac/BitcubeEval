namespace WebApplication.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class initial : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Lecturers", "UserID", "dbo.Users");
            DropIndex("dbo.Lecturers", new[] { "UserID" });
            AddColumn("dbo.Users", "Lecturer_LecturerID", c => c.Int());
            CreateIndex("dbo.Users", "Lecturer_LecturerID");
            AddForeignKey("dbo.Users", "Lecturer_LecturerID", "dbo.Lecturers", "LecturerID");
            DropColumn("dbo.Lecturers", "UserID");
        }

        public override void Down()
        {
            AddColumn("dbo.Lecturers", "UserID", c => c.Int(nullable: false));
            DropForeignKey("dbo.Users", "Lecturer_LecturerID", "dbo.Lecturers");
            DropIndex("dbo.Users", new[] { "Lecturer_LecturerID" });
            DropColumn("dbo.Users", "Lecturer_LecturerID");
            CreateIndex("dbo.Lecturers", "UserID");
            AddForeignKey("dbo.Lecturers", "UserID", "dbo.Users", "UserID", cascadeDelete: true);
        }
    }
}