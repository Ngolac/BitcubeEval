namespace WebApplication.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class initial3 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Users", "Lecturer_LecturerID", "dbo.Lecturers");
            DropIndex("dbo.Users", new[] { "Lecturer_LecturerID" });
            DropColumn("dbo.Users", "Lecturer_LecturerID");
        }

        public override void Down()
        {
            AddColumn("dbo.Users", "Lecturer_LecturerID", c => c.Int());
            CreateIndex("dbo.Users", "Lecturer_LecturerID");
            AddForeignKey("dbo.Users", "Lecturer_LecturerID", "dbo.Lecturers", "LecturerID");
        }
    }
}