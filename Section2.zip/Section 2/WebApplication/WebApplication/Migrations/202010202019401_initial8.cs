namespace WebApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial8 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Lecturers", "FirstName", c => c.String(nullable: false, maxLength: 20));
            AlterColumn("dbo.Lecturers", "LastName", c => c.String(nullable: false, maxLength: 40));
            AlterColumn("dbo.Lecturers", "EmailAddress", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Lecturers", "EmailAddress", c => c.String());
            AlterColumn("dbo.Lecturers", "LastName", c => c.String());
            AlterColumn("dbo.Lecturers", "FirstName", c => c.String());
        }
    }
}
