namespace WebApplication.Migrations
{
    using System.Data.Entity.Migrations;

    public partial class initial1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Users", "ID", c => c.Int(nullable: false));
        }

        public override void Down()
        {
            DropColumn("dbo.Users", "ID");
        }
    }
}