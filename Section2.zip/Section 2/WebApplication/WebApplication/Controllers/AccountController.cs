﻿using System.Linq;
using System.Web.Mvc;
using WebApplication.Models;
using WebApplication.View_Models;

namespace WebApplication.Controllers
{
    public class AccountController : Controller
    {
        private MyBDContext db = new MyBDContext();
       
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(CreateAccount obj)
        {
            User u = new User();
            Lecturer lec = new Lecturer();
            lec.FirstName = obj.FirstName;
            lec.LastName = obj.LastName;
            lec.EmailAddress = obj.EmailAddress;
            lec.DoB = obj.DoB;
            db.Lecturers.Add(lec);
            db.SaveChanges();

            u.UserName = obj.UserName;
            u.Password = obj.Password;
            u.ConfirmPassword = obj.ConfirmPassword;
            u.ID = lec.LecturerID;
            db.Users.Add(u);
            db.SaveChanges();
            return View();
        }

        //GET: Users
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User user)
        {
          
            Lecturer lec = new Lecturer();
            var loggedin = db.Users.Where(x => x.UserName == user.UserName && x.Password == user.Password && user.ID == lec.LecturerID).FirstOrDefault();
            var det = db.Lecturers.Where(a => a.LecturerID == loggedin.ID).FirstOrDefault();
            if (loggedin != null)
            {
                Session["UserName"] = loggedin.UserName.ToString();
                Session["UserId"] = loggedin.UserID;
                Session["Lecturer"] = loggedin.ID;
                Session["Lecture"] = det.FirstName + " " + det.LastName;
                string name = Session["Lecture"].ToString();
                Session["name"] = name;
                return RedirectToAction("Index", "home");
            }
            else
            {
                user.LoginError = "Invalid username or password".ToString();
                return View("Login", user);
            }
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }
    }
}