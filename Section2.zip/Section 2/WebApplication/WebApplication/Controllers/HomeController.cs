﻿using System.Linq;
using System.Web.Mvc;
using WebApplication.Models;
using WebApplication.View_Models;

namespace WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private MyBDContext db = new MyBDContext();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        

        
    }
}