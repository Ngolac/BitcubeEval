﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication.Models
{
    public class UniversityModels
    {
    }

    public class MyDBContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Degree> Degrees { get; set; }
        public DbSet<Lecturer> Lecturers { get; set; }
        public DbSet<User> Users { get; set; }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }
    }

    public class DbSet<T>
    {
        internal void Add(User u)
        {
            throw new NotImplementedException();
        }

        internal object Where(Func<object, object> p)
        {
            throw new NotImplementedException();
        }

        internal void Add(Lecturer lec)
        {
            throw new NotImplementedException();
        }

        internal List<Degree> Tolist()
        {
            throw new NotImplementedException();
        }

        internal Degree Find(int? id)
        {
            throw new NotImplementedException();
        }
    }

    public class DbContext
    {
    }

    public class Student
    {
        [Key, Display(Name = "ID")]
        [ScaffoldColumn(false)]
        public int StudentID { get; set; }

        [Required, StringLength(20), Display(Name = "First Name:")]
        public string FirstName { get; set; }

        [Required, StringLength(40), Display(Name = "Last Name:")]
        public string LastName { get; set; }

        [Required, DataType(DataType.EmailAddress), Display(Name = "Email address:")]
        public string EmailAddress { get; set; }

        [Required, DataType(DataType.Date), Display(Name = "Date of birth:")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DoB { get; set; }

        public int LecturerID { get; set; }
        public Degree Degree { get; set; }
        public virtual Lecturer Lecturer { get; set; }
    }

    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required(ErrorMessage = "This field is required."), Display(Name = "Username:")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.Password), Display(Name = "Password:")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Required(ErrorMessage = "This field is required."), Display(Name = "Confirm Password:")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
        public string LoginError { get; set; }
        public int ID { get; set; }
    }

    public class Degree
    {
        [Key]
        public int DegreeID { get; set; }

        [Required, StringLength(50), Display(Name = "Degree Name")]
        public string DegreeName { get; set; }

        [Required, DataType(DataType.Duration)]
        public int Duration { get; set; }

        public virtual List<Course> courses { get; set; }

        public int LecturerID { get; set; }
        public virtual Lecturer Lecturer { get; set; }
        public virtual List<Student> Students { get; set; }
    }

    public class Lecturer
    {
        [Key]
        public int LecturerID { get; set; }

        [Required, StringLength(20), Display(Name = "First Name:")]
        public string FirstName { get; set; }

        [Required, StringLength(40), Display(Name = "Last Name:")]
        public string LastName { get; set; }

        [Required, DataType(DataType.EmailAddress), Display(Name = "Email address:")]
        public string EmailAddress { get; set; }

        [Required, DataType(DataType.Date), Display(Name = "Date of birth:")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DoB { get; set; }
        public virtual List<Degree> Degrees { get; set; }
        public virtual List<Student> Student { get; set; }
        //public int UserID { get; set;
        
    }

    public class Course
    {
        [Key]
        public int CourseID { get; set; }

        [Required, StringLength(50), Display(Name = "Course Name")]
        public string CourseName { get; set; }

        public int Duration { get; set; }

        [Required, Display(Name = "Degree Name")]
        public int DegreeID { get; set; }

        public Degree Degree { get; set; }
    }
}