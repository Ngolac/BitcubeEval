﻿using System;

namespace WebApplication.Models
{
    internal class indexerAttribute : Attribute
    {
    }
}