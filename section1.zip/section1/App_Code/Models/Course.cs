﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Course
{
    public string CourseName {get ; set ;}
    public int Duration {get;set;}

    public Degree Degree { get; set; }
}
