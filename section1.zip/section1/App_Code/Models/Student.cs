﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// Summary description for Student
/// </summary>
public class Student
{
    public int StudentId { get; set; }
    public string Firstname { get; set; }
    public string LastName { get; set; }
    public string EmailAddress { get; set; }
    public DateTime DoB { get; set; }
    public Degree Degree { get; set; }

}
